tinyMCE.addI18n('en.foswikiimage', {
    image_desc: "Insert an image"
});