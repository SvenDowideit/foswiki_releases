Derived from advimage; check the documentation on that plugin.

This derived version handles Foswiki topic names entered into the
dialog.
