// UK lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Paste as Plain Text',
paste_text_title : 'Use CTRL+V on your keyboard to paste the text into the window.',
paste_text_linebreaks : 'Keep linebreaks',
paste_word_desc : 'Paste from Word',
paste_word_title : 'Use CTRL+V on your keyboard to paste the text into the window.',
selectall_desc : 'Select All'
});
