jQuery(function($){ 
  $('<div style="position: absolute; top:20px; right: 20px;" />').appendTo('body').themeswitcher({
    closeOnSelect: false
  });
});

