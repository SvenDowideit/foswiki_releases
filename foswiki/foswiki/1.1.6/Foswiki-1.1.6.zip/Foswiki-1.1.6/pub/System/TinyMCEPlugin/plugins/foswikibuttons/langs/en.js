tinyMCE.addI18n('en.foswikibuttons', {
    tt_desc: "Typewriter text",
    colour_desc: "Font colour",
    attach_desc: "Manage Attachments",
    indent_desc: "Indent more",
    exdent_desc: "Indent less",
    hide_desc: "Edit Foswiki markup"
});