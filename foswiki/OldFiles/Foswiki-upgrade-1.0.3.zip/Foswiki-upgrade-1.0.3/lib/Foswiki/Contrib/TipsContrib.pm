package Foswiki::Contrib::TipsContrib;
use vars qw( $VERSION );
$VERSION = '$Rev: 1416 (28 Feb 2009) $';
1;
