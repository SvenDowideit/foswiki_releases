package Foswiki::Contrib::PatternSkin;
use vars qw( $VERSION );
$VERSION = '4.0.2';
1;
